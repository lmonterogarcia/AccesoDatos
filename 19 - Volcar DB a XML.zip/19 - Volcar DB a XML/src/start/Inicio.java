package start;

public class Inicio {

	public static void main(String[] args) {
		
		view.FrmPrincipal.inicio();

	}

	

}
